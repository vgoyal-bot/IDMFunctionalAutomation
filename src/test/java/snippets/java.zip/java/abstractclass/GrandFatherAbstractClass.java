package snippets.java.abstractclass;

public abstract class GrandFatherAbstractClass {

    public abstract void grandFatherAbstractMethod1();

    public abstract void grandFatherAbstractMethod2();

    public void grandFatherNormalMethod() {
        System.out.println("Inside grandFatherNormalMethod");
    }
}
