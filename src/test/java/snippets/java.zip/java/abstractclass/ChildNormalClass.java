package snippets.java.abstractclass;

public class ChildNormalClass extends GrandFatherAbstractClass {

    @Override
    public void grandFatherAbstractMethod1() {
        // TODO Auto-generated method stub

    }

    @Override
    public void grandFatherAbstractMethod2() {
        // TODO Auto-generated method stub

    }

}
