package snippets.java.methodoverriding;

public class Test {

}
